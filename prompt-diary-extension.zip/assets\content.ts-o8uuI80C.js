(function(){const Q={free:"Free",plus:"Plus / Pro",pro:"Max / Ultra"},fe=[{key:"chatgpt",name:"ChatGPT",host:/(^|\.)chatgpt\.com$|(^|\.)chat\.openai\.com$/},{key:"claude",name:"Claude",host:/(^|\.)claude\.ai$/},{key:"gemini",name:"Gemini",host:/(^|\.)gemini\.google\.com$/},{key:"perplexity",name:"Perplexity",host:/(^|\.)perplexity\.ai$/},{key:"poe",name:"Poe",host:/(^|\.)poe\.com$/},{key:"deepseek",name:"DeepSeek",host:/(^|\.)chat\.deepseek\.com$/},{key:"grok",name:"Grok",host:/(^|\.)grok\.com$/},{key:"copilot",name:"Copilot",host:/(^|\.)copilot\.microsoft\.com$/},{key:"mistral",name:"Le Chat",host:/(^|\.)chat\.mistral\.ai$/},{key:"kimi",name:"Kimi",host:/(^|\.)kimi\.com$|(^|\.)kimi\.moonshot\.cn$/},{key:"qwen",name:"Qwen",host:/(^|\.)chat\.qwen\.ai$/},{key:"meta",name:"Meta AI",host:/(^|\.)meta\.ai$/}];function he(e){const n=fe.find(t=>t.host.test(e));return n?{key:n.key,name:n.name}:null}const xe={free:{windowHours:5,maxMessages:50,reasoning:{windowHours:24,maxMessages:10}},plus:{windowHours:5,maxMessages:250,reasoning:{windowHours:24,maxMessages:50}},pro:{windowHours:5,maxMessages:null,reasoning:{windowHours:24,maxMessages:null}}},ye={chatgpt:{free:{windowHours:3,maxMessages:15,reasoning:{windowHours:24,maxMessages:5}},plus:{windowHours:3,maxMessages:80,reasoning:{windowHours:168,maxMessages:200}},pro:{windowHours:3,maxMessages:null,reasoning:{windowHours:24,maxMessages:null}}},claude:{free:{windowHours:5,maxMessages:40,reasoning:{windowHours:24,maxMessages:10}},plus:{windowHours:5,maxMessages:200,reasoning:{windowHours:168,maxMessages:100}},pro:{windowHours:5,maxMessages:null,reasoning:{windowHours:168,maxMessages:null}}},gemini:{free:{windowHours:24,maxMessages:100,reasoning:{windowHours:24,maxMessages:20}},plus:{windowHours:24,maxMessages:500,reasoning:{windowHours:24,maxMessages:100}},pro:{windowHours:24,maxMessages:null,reasoning:{windowHours:24,maxMessages:null}}},perplexity:{free:{windowHours:24,maxMessages:100},plus:{windowHours:24,maxMessages:600},pro:{windowHours:24,maxMessages:null}},deepseek:{free:{windowHours:24,maxMessages:200},plus:{windowHours:24,maxMessages:null},pro:{windowHours:24,maxMessages:null}},grok:{free:{windowHours:2,maxMessages:20,reasoning:{windowHours:24,maxMessages:10}},plus:{windowHours:2,maxMessages:100,reasoning:{windowHours:24,maxMessages:50}},pro:{windowHours:2,maxMessages:null,reasoning:{windowHours:24,maxMessages:null}}},copilot:{free:{windowHours:24,maxMessages:300},plus:{windowHours:24,maxMessages:null},pro:{windowHours:24,maxMessages:null}}};function we(e,n){var t;return((t=ye[e])==null?void 0:t[n])??xe[n]}function V(e,n,t){const o=we(e,n);return t&&o.reasoning?o.reasoning:{windowHours:o.windowHours,maxMessages:o.maxMessages}}function T(e){return e?/think|reason|\bo[134]\b|\bpro\b|deep\s?research/i.test(e):!1}function J(e,n){return n===null?"ok":e>=n?"over":e>=n*.7?"warn":"ok"}function Z(e,n,t){const o=t-n*36e5;return e.filter(s=>s>o)}function ee(e,n,t){const o=e[0];if(o===void 0)return null;const s=o+n*36e5-t;if(s<=0)return null;const a=Math.floor(s/36e5),i=Math.ceil(s%36e5/6e4);return a>0?`~${a}h ${i}m`:`~${i}m`}const _=10,B=60,z=document.createElement("div");z.style.all="initial";const $=z.attachShadow({mode:"closed"}),de=document.createElement("style");de.textContent=`
  .pd-bubble, .pd-composer {
    position: fixed;
    z-index: 2147483647;
    display: none;
    align-items: center;
    gap: 6px;
    background: #ffffff;
    color: #0c0a09;
    border: 1px solid #e7e5e4;
    border-radius: 8px;
    padding: 5px 10px;
    font: 600 12px/1 system-ui, sans-serif;
    cursor: pointer;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
    user-select: none;
  }
  .pd-bubble:hover, .pd-composer:hover {
    background: #f0efed;
    border-color: #292524;
  }
  .pd-composer {
    padding: 4px 8px;
    opacity: 0.75;
  }
  .pd-composer:hover { opacity: 1; }
  .pd-mark {
    font-family: Georgia, serif;
    font-style: italic;
    font-weight: 700;
    color: #0c0a09;
    font-size: 13px;
  }
  .pd-toast {
    position: fixed;
    z-index: 2147483647;
    left: 50%;
    bottom: 28px;
    transform: translateX(-50%);
    background: #0c0a09;
    color: #fff;
    border-radius: 8px;
    padding: 8px 16px;
    font: 600 12.5px/1 system-ui, sans-serif;
    display: none;
  }
  .pd-limit {
    position: fixed;
    z-index: 2147483646;
    right: 16px;
    bottom: 16px;
    display: none;
    flex-direction: column;
    gap: 6px;
    background: #ffffff;
    color: #0c0a09;
    border: 1px solid #e7e5e4;
    border-radius: 10px;
    padding: 8px 12px;
    font: 500 11.5px/1.4 system-ui, sans-serif;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
    cursor: pointer;
    user-select: none;
    min-width: 150px;
  }
  .pd-limit-head {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .pd-limit-head .pd-mark { font-size: 12px; }
  .pd-limit-count { margin-left: auto; font-variant-numeric: tabular-nums; color: #57534e; }
  .pd-limit-bar {
    height: 4px;
    border-radius: 9999px;
    background: #f0efed;
    overflow: hidden;
  }
  .pd-limit-fill {
    height: 100%;
    border-radius: 9999px;
    background: #292524;
    width: 0%;
    transition: width 300ms ease-out;
  }
  .pd-limit.warn .pd-limit-fill { background: #8a5a06; }
  .pd-limit.over .pd-limit-fill { background: #dc2626; }
  .pd-limit-note { color: #57534e; font-size: 10.5px; display: none; }
  .pd-limit.over .pd-limit-note { display: block; color: #dc2626; font-weight: 600; }
  .pd-limit-panel { display: none; flex-direction: column; gap: 6px; border-top: 1px solid #e7e5e4; padding-top: 7px; margin-top: 2px; }
  .pd-limit.open .pd-limit-panel { display: flex; }
  .pd-limit-plans { display: flex; gap: 4px; }
  .pd-limit-plan {
    flex: 1;
    border: 1px solid #d6d3d1;
    background: transparent;
    color: #57534e;
    border-radius: 9999px;
    padding: 3px 0;
    font: 500 10.5px/1 system-ui, sans-serif;
    cursor: pointer;
  }
  .pd-limit-plan.active { background: #292524; border-color: #292524; color: #fff; }
  .pd-limit-est { color: #a8a29e; font-size: 10px; }
  /* the head doubles as the drag handle */
  .pd-limit-head { cursor: move; }
  .pd-limit.dragging { transition: none; box-shadow: 0 8px 28px rgba(0,0,0,0.16); }
  .pd-limit.dragging .pd-limit-fill, .pd-limit.dragging .pd-limit-subfill { transition: none; }
  .pd-limit-model {
    display: flex; align-items: center; gap: 5px;
    color: #57534e; font-size: 10.5px; margin-top: -2px;
  }
  .pd-limit-model .pd-model-name {
    max-width: 130px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    font-weight: 600; color: #0c0a09;
  }
  .pd-limit-think {
    flex-shrink: 0; background: #f7ead6; color: #8a5a06;
    border-radius: 9999px; padding: 1px 6px; font-size: 9.5px; font-weight: 700;
    letter-spacing: 0.02em;
  }
  /* reasoning bucket sub-row — only shown once thinking sends exist */
  .pd-limit-sub { display: none; flex-direction: column; gap: 3px; }
  .pd-limit-sub.show { display: flex; }
  .pd-limit-sub-head {
    display: flex; align-items: center; gap: 6px;
    font-size: 10px; color: #8a5a06; font-weight: 600;
  }
  .pd-limit-sub-count { margin-left: auto; font-variant-numeric: tabular-nums; }
  .pd-limit-subbar { height: 3px; border-radius: 9999px; background: #f7ead6; overflow: hidden; }
  .pd-limit-subfill {
    height: 100%; border-radius: 9999px; background: #8a5a06; width: 0%;
    transition: width 300ms ease-out;
  }
  .pd-limit-sub.over .pd-limit-subfill { background: #dc2626; }
`;$.appendChild(de);const m=document.createElement("button");m.className="pd-bubble";m.innerHTML='<span class="pd-mark">Pd</span> Save prompt';$.appendChild(m);const f=document.createElement("button");f.className="pd-composer";f.title="Save this prompt to Prompt Diary";f.innerHTML='<span class="pd-mark">Pd</span>';$.appendChild(f);const E=document.createElement("div");E.className="pd-toast";$.appendChild(E);document.documentElement.appendChild(z);let te=0;function N(e){E.textContent=e,E.style.display="block",clearTimeout(te),te=window.setTimeout(()=>E.style.display="none",1600)}const O=()=>`${location.origin}${location.pathname}`.slice(0,300);function ce(e){const n=e.trim();if(!n)return;const t=n.length>B?`${n.slice(0,B).trimEnd()}…`:n;chrome.runtime.sendMessage({type:"save-prompt",title:t,body:n,sourceConvo:O()},o=>{N(o!=null&&o.ok?o.duplicate?"Already in your diary":o.threadTitle?`Saved → ${o.threadTitle} ✓`:"Saved to Prompt Diary ✓":"Could not save — is the extension enabled?")})}chrome.runtime.onMessage.addListener((e,n,t)=>{if((e==null?void 0:e.type)==="capture-transcript"){t($e());return}if((e==null?void 0:e.type)!=="insert-prompt"||!e.body)return;const o=h==null?void 0:h();if(!o){t({ok:!1});return}o.focus(),o instanceof HTMLTextAreaElement?(o.value=o.value?`${o.value}
${e.body}`:e.body,o.dispatchEvent(new Event("input",{bubbles:!0}))):document.execCommand("insertText",!1,e.body),N("Inserted from Prompt Diary ✓"),t({ok:!0})});function ue(){const e=window.getSelection();return!e||e.isCollapsed?"":e.toString().trim()}function pe(){const e=window.getSelection(),n=ue();if(!e||n.length<_){m.style.display="none";return}const t=e.getRangeAt(0).getBoundingClientRect();if(!t.width&&!t.height){m.style.display="none";return}m.style.display="flex",m.style.left=`${Math.max(8,t.left+t.width/2-55)}px`,m.style.top=`${Math.max(8,t.top-38)}px`}document.addEventListener("mouseup",()=>setTimeout(pe,10));document.addEventListener("keyup",e=>{(e.key==="Shift"||e.key.startsWith("Arrow"))&&pe()});document.addEventListener("mousedown",()=>m.style.display="none");document.addEventListener("scroll",()=>m.style.display="none",!0);m.addEventListener("mousedown",e=>{e.preventDefault(),e.stopPropagation(),ce(ue()),m.style.display="none"});const be=[{host:/(^|\.)chatgpt\.com$|(^|\.)chat\.openai\.com$/,find:()=>document.querySelector("#prompt-textarea")},{host:/(^|\.)claude\.ai$/,find:()=>document.querySelector('div[contenteditable="true"].ProseMirror')??document.querySelector('div[contenteditable="true"]')},{host:/(^|\.)gemini\.google\.com$/,find:()=>document.querySelector('div[contenteditable="true"]')},{host:/(^|\.)perplexity\.ai$/,find:()=>document.querySelector("textarea")},{host:/(^|\.)poe\.com$/,find:()=>document.querySelector("textarea")}];var ae;const h=(ae=be.find(e=>e.host.test(location.hostname)))==null?void 0:ae.find;function ve(e){return e instanceof HTMLTextAreaElement?e.value:e.innerText??""}let H=null;function me(){if(!h)return;if(H=h(),!H){f.style.display="none";return}const e=H.getBoundingClientRect();if(!e.width||!e.height){f.style.display="none";return}f.style.display="flex",f.style.left=`${e.right-34}px`,f.style.top=`${Math.max(8,e.top-30)}px`}setInterval(()=>{h&&me(),Pe(),b()},600);h&&window.addEventListener("resize",me);f.addEventListener("mousedown",e=>{if(e.preventDefault(),e.stopPropagation(),!H)return;const n=ve(H);if(n.trim().length===0){N("Chatbox is empty — nothing to save");return}ce(n)});const ke=[{host:/chatgpt\.com|chat\.openai\.com/,selector:"[data-message-author-role]"},{host:/claude\.ai/,selector:"div[data-is-streaming='false'], div.font-claude-message, div.font-claude-response, div[data-testid='user-message']"},{host:/gemini\.google\.com/,selector:"message-content"}];var re;const P=(re=ke.find(e=>e.host.test(location.hostname)))==null?void 0:re.selector,Me="pdSaveInjected",q=6e4,L=/chatgpt\.com|chat\.openai\.com/.test(location.hostname)?"chatgpt":/claude\.ai/.test(location.hostname)?"claude":/gemini\.google\.com/.test(location.hostname)?"gemini":null;function Ee(e){var n;if(L==="chatgpt"){const t=(n=e.closest("[data-message-author-role]"))==null?void 0:n.getAttribute("data-message-author-role");return t==="user"?"user":t==="assistant"?"assistant":void 0}if(L==="claude")return e.closest("[data-testid='user-message']")?"user":"assistant";if(L==="gemini")return e.closest("user-query")?"user":"assistant"}const d=he(location.hostname);let x={standard:[],reasoning:[]},S="free",ne=0,p={model:"",thinking:!1};const w=e=>((e==null?void 0:e.textContent)??"").trim();function D(){const e=d==null?void 0:d.key,n=()=>[...document.querySelectorAll('[aria-pressed="true"], [data-state="on"]')].some(t=>{const o=`${w(t)} ${t.getAttribute("aria-label")??""}`;return/think|reason/i.test(o)});try{if(e==="chatgpt"){const t=document.querySelector('[data-testid="model-switcher-dropdown-button"]')??document.querySelector('button[aria-label*="model" i]')??[...document.querySelectorAll("main button, header button")].find(s=>/gpt|o[134]\b|thinking/i.test(w(s))),o=w(t).replace(/^chatgpt\s*/i,"").slice(0,40)||"GPT";return{model:o,thinking:T(o)||n()}}if(e==="claude"){const t=[...document.querySelectorAll("button")].find(s=>/claude|sonnet|opus|haiku|fable/i.test(w(s))),o=w(t).slice(0,40)||"Claude";return{model:o,thinking:T(o)||n()}}if(e==="gemini"){const t=[...document.querySelectorAll("button, [role='button']")].find(s=>/2\.\d|flash|pro|gemini/i.test(w(s))),o=w(t).replace(/^gemini\s*/i,"").slice(0,40)||"Gemini";return{model:o,thinking:T(o)||n()}}}catch{}return{model:"",thinking:!1}}function oe(){d&&chrome.runtime.sendMessage({type:"get-usage",site:d.key},e=>{chrome.runtime.lastError||!(e!=null&&e.buckets)||(x=e.buckets,b())})}if(d){chrome.storage.local.get("sitePlans").then(t=>{S=(t.sitePlans??{})[d.key]??"free",p=D(),Se(),oe()}),setInterval(oe,3e4),setInterval(()=>{const t=D();(t.model!==p.model||t.thinking!==p.thinking)&&(p=t,b())},3e3);const e=t=>t instanceof HTMLTextAreaElement||t instanceof HTMLInputElement&&t.type==="text"?t.value:t instanceof HTMLElement&&t.isContentEditable?t.innerText:null,n=()=>{const t=Date.now();if(t-ne<1500)return;ne=t,p=D();const o=p.thinking||T(p.model);o?x={...x,reasoning:[...x.reasoning,t]}:x={...x,standard:[...x.standard,t]},b();const s=d.key,a=p.model;chrome.runtime.sendMessage({type:"usage-msg",site:s,reasoning:o,model:a},()=>{chrome.runtime.lastError&&chrome.storage.local.get(["usageEvents","usageLocalLog"]).then(i=>{const c=i.usageEvents??[];c.push({site:s,at:t,reasoning:o,model:a});const g=i.usageLocalLog??{},u=g[s],l=Array.isArray(u)?{standard:u,reasoning:[]}:u&&typeof u=="object"?{standard:u.standard??[],reasoning:u.reasoning??[]}:{standard:[],reasoning:[]};o?l.reasoning=[...l.reasoning,t]:l.standard=[...l.standard,t],g[s]=l,chrome.storage.local.set({usageEvents:c.slice(-500),usageLocalLog:g})})})};document.addEventListener("keydown",t=>{if(t.key!=="Enter"||t.shiftKey||t.isComposing)return;const o=e(t.target);o&&o.trim().length>0&&n()},!0),document.addEventListener("click",t=>{const o=t.target instanceof Element?t.target:null;if(!(o==null?void 0:o.closest("button[data-testid*='send' i], button[aria-label*='send' i], button[type='submit']")))return;const a=(h==null?void 0:h())??document.querySelector("textarea, [contenteditable='true']");(a?a instanceof HTMLTextAreaElement?a.value:a.innerText:"").trim().length>0&&n()},!0)}const r=document.createElement("div");r.className="pd-limit";$.appendChild(r);let R=!1;function F(e,n){const t=r.getBoundingClientRect(),o=t.width||160,s=t.height||60;return{x:Math.min(Math.max(4,e),Math.max(4,window.innerWidth-o-4)),y:Math.min(Math.max(4,n),Math.max(4,window.innerHeight-s-4))}}function A(e,n){r.style.left=`${e}px`,r.style.top=`${n}px`,r.style.right="auto",r.style.bottom="auto"}function He(){chrome.storage.local.get("pdLimitPos").then(e=>{const n=e.pdLimitPos;if(n){const t=F(n.x,n.y);A(t.x,t.y)}else{const t=r.getBoundingClientRect();A(window.innerWidth-(t.width||160)-16,window.innerHeight-(t.height||60)-16)}})}function Le(){const e=r.querySelector(".pd-limit-head");e&&e.addEventListener("pointerdown",n=>{n.preventDefault();const t=r.getBoundingClientRect(),o=t.left,s=t.top,a=n.clientX,i=n.clientY;let c=!1;e.setPointerCapture(n.pointerId),r.classList.add("dragging");const g=l=>{const v=l.clientX-a,k=l.clientY-i;Math.abs(v)+Math.abs(k)>3&&(c=!0);const M=F(o+v,s+k);A(M.x,M.y)},u=()=>{if(e.removeEventListener("pointermove",g),e.removeEventListener("pointerup",u),r.classList.remove("dragging"),c){R=!0;const l=r.getBoundingClientRect();chrome.storage.local.set({pdLimitPos:{x:l.left,y:l.top}}),setTimeout(()=>R=!1,0)}};e.addEventListener("pointermove",g),e.addEventListener("pointerup",u)})}function Se(){if(!d)return;r.innerHTML=`
    <div class="pd-limit-head">
      <span class="pd-mark">Pd</span>
      <span class="pd-limit-label"></span>
      <span class="pd-limit-count"></span>
    </div>
    <div class="pd-limit-model">
      <span class="pd-model-name"></span>
      <span class="pd-limit-think">THINKING</span>
    </div>
    <div class="pd-limit-bar"><div class="pd-limit-fill"></div></div>
    <div class="pd-limit-sub">
      <div class="pd-limit-sub-head"><span>Thinking</span><span class="pd-limit-sub-count"></span></div>
      <div class="pd-limit-subbar"><div class="pd-limit-subfill"></div></div>
    </div>
    <div class="pd-limit-note"></div>
    <div class="pd-limit-panel">
      <div class="pd-limit-plans"></div>
      <span class="pd-limit-est">Estimated from your sends — not an official meter. Drag to move.</span>
    </div>`;const e=r.querySelector(".pd-limit-plans");Object.keys(Q).forEach(n=>{const t=document.createElement("button");t.className="pd-limit-plan",t.dataset.plan=n,t.textContent=Q[n],t.addEventListener("click",o=>{o.stopPropagation(),S=n,chrome.storage.local.get("sitePlans").then(s=>{const a=s.sitePlans??{};a[d.key]=n,chrome.storage.local.set({sitePlans:a})}),b()}),e.appendChild(t)}),r.addEventListener("click",()=>{R||r.classList.toggle("open")}),r.style.display="flex",Le(),He(),window.addEventListener("resize",()=>{const n=r.getBoundingClientRect(),t=F(n.left,n.top);A(t.x,t.y)}),b()}function b(){if(!d||r.style.display==="none")return;const e=Date.now(),n=V(d.key,S,!1),t=V(d.key,S,!0),o=t.maxMessages!==n.maxMessages||t.windowHours!==n.windowHours,s=Z(x.standard,n.windowHours,e),a=Z(x.reasoning,t.windowHours,e),i=o?s.length:s.length+a.length,c=J(i,n.maxMessages),g=o?J(a.length,t.maxMessages):"ok",u=c==="over"||g==="over"?"over":c==="warn"||g==="warn"?"warn":"ok";r.classList.remove("warn","over"),u!=="ok"&&r.classList.add(u);const l=y=>r.querySelector(y),v=l(".pd-limit-label"),k=l(".pd-limit-count"),M=l(".pd-limit-fill"),G=l(".pd-limit-note"),X=l(".pd-model-name"),j=l(".pd-limit-think"),I=l(".pd-limit-sub"),W=l(".pd-limit-sub-count"),Y=l(".pd-limit-subfill");if(!v||!k||!M||!G)return;if(v.textContent=`${d.name} · ${n.windowHours}h`,k.textContent=n.maxMessages===null?`${i} · ∞`:`${i}/${n.maxMessages}`,M.style.width=n.maxMessages===null?"4%":`${Math.min(100,i/n.maxMessages*100)}%`,X&&(X.textContent=p.model||"detecting model…"),j&&(j.style.display=p.thinking?"inline-block":"none"),I&&W&&Y){const y=o&&(a.length>0||p.thinking);if(I.classList.toggle("show",y),I.classList.toggle("over",g==="over"),y){const ge=t.windowHours>=168?`${Math.round(t.windowHours/24)}d`:`${t.windowHours}h`;W.textContent=t.maxMessages===null?`${a.length} · ∞`:`${a.length}/${t.maxMessages} · ${ge}`,Y.style.width=t.maxMessages===null?"4%":`${Math.min(100,a.length/t.maxMessages*100)}%`}}const K=ee(a,t.windowHours,e),U=ee(s,n.windowHours,e);G.textContent=g==="over"?`Thinking limit likely reached${K?` · frees in ${K}`:""}`:c==="over"?`Limit likely reached${U?` · frees in ${U}`:""}`:"",r.querySelectorAll(".pd-limit-plan").forEach(y=>{y.classList.toggle("active",y.dataset.plan===S)})}function $e(){if(!P||!L)return{ok:!1,reason:"unsupported"};const e=[];for(const i of document.querySelectorAll(P))i.closest("[data-is-streaming='true']")||e.some(c=>c.contains(i))||e.push(i);const n=document.querySelectorAll("[data-pd-btn]");n.forEach(i=>i.style.display="none");let t=e.map(i=>({role:Ee(i),text:i.innerText.trim()})).filter(i=>i.text.length>=_);if(n.forEach(i=>i.style.display="inline-flex"),t.length===0)return{ok:!1,reason:"empty"};let o=t.reduce((i,c)=>i+c.text.length,0),s=!1;for(;o>q&&t.length>1;){const i=t.shift();o-=(i==null?void 0:i.text.length)??0,s=!0}const a=t[0];return a&&o>q&&(a.text=a.text.slice(-q),o=a.text.length,s=!0),{ok:!0,handoff:{site:L,url:O(),title:document.title.trim().slice(0,80)||"Untitled conversation",capturedAt:new Date().toISOString(),messages:t,charCount:o,truncated:s}}}var le;const se=(le=[["chatgpt",/chatgpt\.com|chat\.openai\.com/],["claude",/claude\.ai/],["gemini",/gemini\.google\.com/],["perplexity",/perplexity\.ai/],["poe",/poe\.com/]].find(([,e])=>e.test(location.hostname)))==null?void 0:le[0];let C=0;function Te(e){C+=e}setInterval(()=>{if(!se||C===0)return;const e=Math.ceil(C/4);C=0;const n=(p.model||"").replace(/\|/g," "),t=`${new Date().toISOString().slice(0,10)}|${se}|${n}`;chrome.storage.local.get("usagePending").then(o=>{const s=o.usagePending??{};chrome.storage.local.set({usagePending:{...s,[t]:(s[t]??0)+e}})})},5e3);const ie='<span style="font-family:Georgia,serif;font-style:italic;font-weight:700;color:#0c0a09">Pd</span><span style="color:#0c0a09">Save</span>';function Ce(e){const n=document.createElement("button");return n.type="button",n.dataset.pdBtn="1",n.innerHTML=ie,n.title="Save this message to Prompt Diary",Object.assign(n.style,{display:"inline-flex",alignItems:"center",gap:"5px",marginTop:"6px",padding:"3px 9px",font:"600 11px/1.4 system-ui, sans-serif",color:"#0c0a09",background:"#ffffff",border:"1px solid #e7e5e4",borderRadius:"8px",cursor:"pointer",boxShadow:"0 2px 8px rgba(0, 0, 0, 0.14)",opacity:"0.95"}),n.addEventListener("mouseenter",()=>{n.style.opacity="1",n.style.background="#f0efed"}),n.addEventListener("mouseleave",()=>{n.style.opacity="0.95",n.style.background="#ffffff"}),n.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation(),n.style.display="none";const o=e.innerText;n.style.display="inline-flex",n.textContent="Saving…",chrome.runtime.sendMessage({type:"save-prompt",title:o.slice(0,B),body:o.trim(),sourceConvo:O()},s=>{chrome.runtime.lastError&&console.warn("[prompt-diary]",chrome.runtime.lastError.message),n.textContent=s!=null&&s.ok?s.duplicate?"Already saved =":"Saved ✓":"Failed — reload extension",n.style.opacity="1",setTimeout(()=>{n.innerHTML=ie,n.style.opacity="0.95"},2e3)})}),n}function Pe(){if(P)for(const e of document.querySelectorAll(P)){if(e.closest("[data-pd-save-injected='1']")||e.closest("[data-is-streaming='true']"))continue;const n=(e.innerText??"").trim().length;n<_||(e.dataset[Me]="1",Te(n),e.appendChild(Ce(e)))}}
})()
