(function(){const P={free:"Free",plus:"Plus / Pro",pro:"Max / Ultra"},j=[{key:"chatgpt",name:"ChatGPT",host:/(^|\.)chatgpt\.com$|(^|\.)chat\.openai\.com$/},{key:"claude",name:"Claude",host:/(^|\.)claude\.ai$/},{key:"gemini",name:"Gemini",host:/(^|\.)gemini\.google\.com$/},{key:"perplexity",name:"Perplexity",host:/(^|\.)perplexity\.ai$/},{key:"poe",name:"Poe",host:/(^|\.)poe\.com$/},{key:"deepseek",name:"DeepSeek",host:/(^|\.)chat\.deepseek\.com$/},{key:"grok",name:"Grok",host:/(^|\.)grok\.com$/},{key:"copilot",name:"Copilot",host:/(^|\.)copilot\.microsoft\.com$/},{key:"mistral",name:"Le Chat",host:/(^|\.)chat\.mistral\.ai$/},{key:"kimi",name:"Kimi",host:/(^|\.)kimi\.com$|(^|\.)kimi\.moonshot\.cn$/},{key:"qwen",name:"Qwen",host:/(^|\.)chat\.qwen\.ai$/},{key:"meta",name:"Meta AI",host:/(^|\.)meta\.ai$/}];function G(e){const t=j.find(n=>n.host.test(e));return t?{key:t.key,name:t.name}:null}const U={free:{windowHours:5,maxMessages:50},plus:{windowHours:5,maxMessages:250},pro:{windowHours:5,maxMessages:null}},W={chatgpt:{free:{windowHours:3,maxMessages:15},plus:{windowHours:3,maxMessages:80},pro:{windowHours:3,maxMessages:null}},claude:{free:{windowHours:5,maxMessages:40},plus:{windowHours:5,maxMessages:200},pro:{windowHours:5,maxMessages:null}},gemini:{free:{windowHours:24,maxMessages:100},plus:{windowHours:24,maxMessages:500},pro:{windowHours:24,maxMessages:null}},perplexity:{free:{windowHours:24,maxMessages:100},plus:{windowHours:24,maxMessages:600},pro:{windowHours:24,maxMessages:null}},deepseek:{free:{windowHours:24,maxMessages:200},plus:{windowHours:24,maxMessages:null},pro:{windowHours:24,maxMessages:null}},grok:{free:{windowHours:2,maxMessages:20},plus:{windowHours:2,maxMessages:100},pro:{windowHours:2,maxMessages:null}},copilot:{free:{windowHours:24,maxMessages:300},plus:{windowHours:24,maxMessages:null},pro:{windowHours:24,maxMessages:null}}};function X(e,t){var n;return((n=W[e])==null?void 0:n[t])??U[t]}function Y(e,t){return t===null?"ok":e>=t?"over":e>=t*.7?"warn":"ok"}function Q(e,t,n){const o=n-t*36e5;return e.filter(i=>i>o)}function J(e,t,n){const o=e[0];if(o===void 0)return null;const i=o+t*36e5-n;if(i<=0)return null;const a=Math.floor(i/36e5),s=Math.ceil(i%36e5/6e4);return a>0?`~${a}h ${s}m`:`~${s}m`}const M=10,E=60,S=document.createElement("div");S.style.all="initial";const x=S.attachShadow({mode:"closed"}),R=document.createElement("style");R.textContent=`
  .pd-bubble, .pd-composer {
    position: fixed;
    z-index: 2147483647;
    display: none;
    align-items: center;
    gap: 6px;
    background: #ffffff;
    color: #0c0a09;
    border: 1px solid #e7e5e4;
    border-radius: 8px;
    padding: 5px 10px;
    font: 600 12px/1 system-ui, sans-serif;
    cursor: pointer;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
    user-select: none;
  }
  .pd-bubble:hover, .pd-composer:hover {
    background: #f0efed;
    border-color: #292524;
  }
  .pd-composer {
    padding: 4px 8px;
    opacity: 0.75;
  }
  .pd-composer:hover { opacity: 1; }
  .pd-mark {
    font-family: Georgia, serif;
    font-style: italic;
    font-weight: 700;
    color: #0c0a09;
    font-size: 13px;
  }
  .pd-toast {
    position: fixed;
    z-index: 2147483647;
    left: 50%;
    bottom: 28px;
    transform: translateX(-50%);
    background: #0c0a09;
    color: #fff;
    border-radius: 8px;
    padding: 8px 16px;
    font: 600 12.5px/1 system-ui, sans-serif;
    display: none;
  }
  .pd-limit {
    position: fixed;
    z-index: 2147483646;
    right: 16px;
    bottom: 16px;
    display: none;
    flex-direction: column;
    gap: 6px;
    background: #ffffff;
    color: #0c0a09;
    border: 1px solid #e7e5e4;
    border-radius: 10px;
    padding: 8px 12px;
    font: 500 11.5px/1.4 system-ui, sans-serif;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
    cursor: pointer;
    user-select: none;
    min-width: 150px;
  }
  .pd-limit-head {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .pd-limit-head .pd-mark { font-size: 12px; }
  .pd-limit-count { margin-left: auto; font-variant-numeric: tabular-nums; color: #57534e; }
  .pd-limit-bar {
    height: 4px;
    border-radius: 9999px;
    background: #f0efed;
    overflow: hidden;
  }
  .pd-limit-fill {
    height: 100%;
    border-radius: 9999px;
    background: #292524;
    width: 0%;
    transition: width 300ms ease-out;
  }
  .pd-limit.warn .pd-limit-fill { background: #8a5a06; }
  .pd-limit.over .pd-limit-fill { background: #dc2626; }
  .pd-limit-note { color: #57534e; font-size: 10.5px; display: none; }
  .pd-limit.over .pd-limit-note { display: block; color: #dc2626; font-weight: 600; }
  .pd-limit-panel { display: none; flex-direction: column; gap: 6px; border-top: 1px solid #e7e5e4; padding-top: 7px; margin-top: 2px; }
  .pd-limit.open .pd-limit-panel { display: flex; }
  .pd-limit-plans { display: flex; gap: 4px; }
  .pd-limit-plan {
    flex: 1;
    border: 1px solid #d6d3d1;
    background: transparent;
    color: #57534e;
    border-radius: 9999px;
    padding: 3px 0;
    font: 500 10.5px/1 system-ui, sans-serif;
    cursor: pointer;
  }
  .pd-limit-plan.active { background: #292524; border-color: #292524; color: #fff; }
  .pd-limit-est { color: #a8a29e; font-size: 10px; }
`;x.appendChild(R);const l=document.createElement("button");l.className="pd-bubble";l.innerHTML='<span class="pd-mark">Pd</span> Save prompt';x.appendChild(l);const d=document.createElement("button");d.className="pd-composer";d.title="Save this prompt to Prompt Diary";d.innerHTML='<span class="pd-mark">Pd</span>';x.appendChild(d);const m=document.createElement("div");m.className="pd-toast";x.appendChild(m);document.documentElement.appendChild(S);let A=0;function T(e){m.textContent=e,m.style.display="block",clearTimeout(A),A=window.setTimeout(()=>m.style.display="none",1600)}const C=()=>`${location.origin}${location.pathname}`.slice(0,300);function N(e){const t=e.trim();if(!t)return;const n=t.length>E?`${t.slice(0,E).trimEnd()}…`:t;chrome.runtime.sendMessage({type:"save-prompt",title:n,body:t,sourceConvo:C()},o=>{T(o!=null&&o.ok?o.duplicate?"Already in your diary":o.threadTitle?`Saved → ${o.threadTitle} ✓`:"Saved to Prompt Diary ✓":"Could not save — is the extension enabled?")})}chrome.runtime.onMessage.addListener((e,t,n)=>{if((e==null?void 0:e.type)==="capture-transcript"){n(se());return}if((e==null?void 0:e.type)!=="insert-prompt"||!e.body)return;const o=c==null?void 0:c();if(!o){n({ok:!1});return}o.focus(),o instanceof HTMLTextAreaElement?(o.value=o.value?`${o.value}
${e.body}`:e.body,o.dispatchEvent(new Event("input",{bubbles:!0}))):document.execCommand("insertText",!1,e.body),T("Inserted from Prompt Diary ✓"),n({ok:!0})});function z(){const e=window.getSelection();return!e||e.isCollapsed?"":e.toString().trim()}function F(){const e=window.getSelection(),t=z();if(!e||t.length<M){l.style.display="none";return}const n=e.getRangeAt(0).getBoundingClientRect();if(!n.width&&!n.height){l.style.display="none";return}l.style.display="flex",l.style.left=`${Math.max(8,n.left+n.width/2-55)}px`,l.style.top=`${Math.max(8,n.top-38)}px`}document.addEventListener("mouseup",()=>setTimeout(F,10));document.addEventListener("keyup",e=>{(e.key==="Shift"||e.key.startsWith("Arrow"))&&F()});document.addEventListener("mousedown",()=>l.style.display="none");document.addEventListener("scroll",()=>l.style.display="none",!0);l.addEventListener("mousedown",e=>{e.preventDefault(),e.stopPropagation(),N(z()),l.style.display="none"});const V=[{host:/(^|\.)chatgpt\.com$|(^|\.)chat\.openai\.com$/,find:()=>document.querySelector("#prompt-textarea")},{host:/(^|\.)claude\.ai$/,find:()=>document.querySelector('div[contenteditable="true"].ProseMirror')??document.querySelector('div[contenteditable="true"]')},{host:/(^|\.)gemini\.google\.com$/,find:()=>document.querySelector('div[contenteditable="true"]')},{host:/(^|\.)perplexity\.ai$/,find:()=>document.querySelector("textarea")},{host:/(^|\.)poe\.com$/,find:()=>document.querySelector("textarea")}];var _;const c=(_=V.find(e=>e.host.test(location.hostname)))==null?void 0:_.find;function Z(e){return e instanceof HTMLTextAreaElement?e.value:e.innerText??""}let f=null;function K(){if(!c)return;if(f=c(),!f){d.style.display="none";return}const e=f.getBoundingClientRect();if(!e.width||!e.height){d.style.display="none";return}d.style.display="flex",d.style.left=`${e.right-34}px`,d.style.top=`${Math.max(8,e.top-30)}px`}setInterval(()=>{c&&K(),re(),h()},600);c&&window.addEventListener("resize",K);d.addEventListener("mousedown",e=>{if(e.preventDefault(),e.stopPropagation(),!f)return;const t=Z(f);if(t.trim().length===0){T("Chatbox is empty — nothing to save");return}N(t)});const ee=[{host:/chatgpt\.com|chat\.openai\.com/,selector:"[data-message-author-role]"},{host:/claude\.ai/,selector:"div[data-is-streaming='false'], div.font-claude-message, div.font-claude-response, div[data-testid='user-message']"},{host:/gemini\.google\.com/,selector:"message-content"}];var O;const v=(O=ee.find(e=>e.host.test(location.hostname)))==null?void 0:O.selector,te="pdSaveInjected",k=6e4,g=/chatgpt\.com|chat\.openai\.com/.test(location.hostname)?"chatgpt":/claude\.ai/.test(location.hostname)?"claude":/gemini\.google\.com/.test(location.hostname)?"gemini":null;function ne(e){var t;if(g==="chatgpt"){const n=(t=e.closest("[data-message-author-role]"))==null?void 0:t.getAttribute("data-message-author-role");return n==="user"?"user":n==="assistant"?"assistant":void 0}if(g==="claude")return e.closest("[data-testid='user-message']")?"user":"assistant";if(g==="gemini")return e.closest("user-query")?"user":"assistant"}const p=G(location.hostname);let w=[],b="free",I=0;function q(){p&&chrome.runtime.sendMessage({type:"get-usage",site:p.key},e=>{chrome.runtime.lastError||!(e!=null&&e.timestamps)||(w=e.timestamps,h())})}if(p){chrome.storage.local.get("sitePlans").then(n=>{b=(n.sitePlans??{})[p.key]??"free",oe(),q()}),setInterval(q,3e4);const e=n=>n instanceof HTMLTextAreaElement||n instanceof HTMLInputElement&&n.type==="text"?n.value:n instanceof HTMLElement&&n.isContentEditable?n.innerText:null,t=()=>{const n=Date.now();n-I<1500||(I=n,w=[...w,n],h(),chrome.runtime.sendMessage({type:"usage-msg",site:p.key},()=>{chrome.runtime.lastError}))};document.addEventListener("keydown",n=>{if(n.key!=="Enter"||n.shiftKey||n.isComposing)return;const o=e(n.target);o&&o.trim().length>0&&t()},!0),document.addEventListener("click",n=>{const o=n.target instanceof Element?n.target:null;if(!(o==null?void 0:o.closest("button[data-testid*='send' i], button[aria-label*='send' i], button[type='submit']")))return;const a=(c==null?void 0:c())??document.querySelector("textarea, [contenteditable='true']");(a?a instanceof HTMLTextAreaElement?a.value:a.innerText:"").trim().length>0&&t()},!0)}const r=document.createElement("div");r.className="pd-limit";x.appendChild(r);function oe(){if(!p)return;r.innerHTML=`
    <div class="pd-limit-head">
      <span class="pd-mark">Pd</span>
      <span class="pd-limit-label"></span>
      <span class="pd-limit-count"></span>
    </div>
    <div class="pd-limit-bar"><div class="pd-limit-fill"></div></div>
    <div class="pd-limit-note"></div>
    <div class="pd-limit-panel">
      <div class="pd-limit-plans"></div>
      <span class="pd-limit-est">Estimated from your sends — not an official meter.</span>
    </div>`;const e=r.querySelector(".pd-limit-plans");Object.keys(P).forEach(t=>{const n=document.createElement("button");n.className="pd-limit-plan",n.dataset.plan=t,n.textContent=P[t],n.addEventListener("click",o=>{o.stopPropagation(),b=t,chrome.storage.local.get("sitePlans").then(i=>{const a=i.sitePlans??{};a[p.key]=t,chrome.storage.local.set({sitePlans:a})}),h()}),e.appendChild(n)}),r.addEventListener("click",()=>r.classList.toggle("open")),r.style.display="flex",h()}function h(){if(!p||r.style.display==="none")return;const{windowHours:e,maxMessages:t}=X(p.key,b),n=Q(w,e,Date.now()),o=n.length,i=Y(o,t);r.classList.remove("warn","over"),i!=="ok"&&r.classList.add(i);const a=r.querySelector(".pd-limit-label"),s=r.querySelector(".pd-limit-count"),u=r.querySelector(".pd-limit-fill"),$=r.querySelector(".pd-limit-note");if(!a||!s||!u||!$)return;a.textContent=`${p.name} · ${e}h`,s.textContent=t===null?`${o} msgs · ∞`:`${o}/${t} msgs`,u.style.width=t===null?"4%":`${Math.min(100,o/t*100)}%`;const L=J(n,e,Date.now());$.textContent=i==="over"?`Limit likely reached${L?` · frees up in ${L}`:""}`:"",r.querySelectorAll(".pd-limit-plan").forEach(H=>{H.classList.toggle("active",H.dataset.plan===b)})}function se(){if(!v||!g)return{ok:!1,reason:"unsupported"};const e=[];for(const s of document.querySelectorAll(v))s.closest("[data-is-streaming='true']")||e.some(u=>u.contains(s))||e.push(s);const t=document.querySelectorAll("[data-pd-btn]");t.forEach(s=>s.style.display="none");let n=e.map(s=>({role:ne(s),text:s.innerText.trim()})).filter(s=>s.text.length>=M);if(t.forEach(s=>s.style.display="inline-flex"),n.length===0)return{ok:!1,reason:"empty"};let o=n.reduce((s,u)=>s+u.text.length,0),i=!1;for(;o>k&&n.length>1;){const s=n.shift();o-=(s==null?void 0:s.text.length)??0,i=!0}const a=n[0];return a&&o>k&&(a.text=a.text.slice(-k),o=a.text.length,i=!0),{ok:!0,handoff:{site:g,url:C(),title:document.title.trim().slice(0,80)||"Untitled conversation",capturedAt:new Date().toISOString(),messages:n,charCount:o,truncated:i}}}var B;const D=(B=[["chatgpt",/chatgpt\.com|chat\.openai\.com/],["claude",/claude\.ai/],["gemini",/gemini\.google\.com/],["perplexity",/perplexity\.ai/],["poe",/poe\.com/]].find(([,e])=>e.test(location.hostname)))==null?void 0:B[0];let y=0;function ie(e){y+=e}setInterval(()=>{if(!D||y===0)return;const e=Math.ceil(y/4);y=0;const t=`${new Date().toISOString().slice(0,10)}|${D}`;chrome.storage.local.get("usagePending").then(n=>{const o=n.usagePending??{};chrome.storage.local.set({usagePending:{...o,[t]:(o[t]??0)+e}})})},5e3);function ae(e){const t=document.createElement("button");return t.type="button",t.dataset.pdBtn="1",t.textContent="Pd · Save",t.title="Save this message to Prompt Diary",Object.assign(t.style,{display:"inline-flex",alignItems:"center",marginTop:"6px",padding:"3px 9px",font:"600 11px/1.4 system-ui, sans-serif",color:"#292524",background:"transparent",border:"1px solid rgba(41, 37, 36, 0.35)",borderRadius:"6px",cursor:"pointer",opacity:"0.7"}),t.addEventListener("mouseenter",()=>t.style.opacity="1"),t.addEventListener("mouseleave",()=>t.style.opacity="0.7"),t.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),t.style.display="none";const o=e.innerText;t.style.display="inline-flex",t.textContent="Saving…",chrome.runtime.sendMessage({type:"save-prompt",title:o.slice(0,E),body:o.trim(),sourceConvo:C()},i=>{chrome.runtime.lastError&&console.warn("[prompt-diary]",chrome.runtime.lastError.message),t.textContent=i!=null&&i.ok?i.duplicate?"Already saved =":"Saved ✓":"Failed — reload extension",t.style.opacity="1",setTimeout(()=>{t.textContent="Pd · Save",t.style.opacity="0.7"},2e3)})}),t}function re(){if(v)for(const e of document.querySelectorAll(v)){if(e.closest("[data-pd-save-injected='1']")||e.closest("[data-is-streaming='true']"))continue;const t=(e.innerText??"").trim().length;t<M||(e.dataset[te]="1",ie(t),e.appendChild(ae(e)))}}
})()
